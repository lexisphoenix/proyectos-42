/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anieto-m <anieto-m@student.42malaga.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 20:05:00 by anieto-m          #+#    #+#             */
/*   Updated: 2025/08/12 16:20:20 by anieto-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <limits.h>
#include "ft_printf.h"

int main(void)
{
	int numeromaximo;
	int numerominimo;
	int numero;
	int numero2;

	numeromaximo = 2147483647;
	numerominimo = -2147483648;
	numero = 255;
	numero2 = -1;

	ft_printf("ft_printf c: %c\n", 'S');
	printf("printf c: %c\n", 'S');
	ft_printf("ft_printf s: %s\n", "Code is Poetry");
	printf("printf s: %s\n", "Code is Poetry");
	ft_printf("ft_printf d: numero positivo maximo. %d\n", numeromaximo);
	printf("printf d: numero positivo maximo. %d\n", numeromaximo);
	ft_printf("ft_printf d: numero negativo minimo. %d\n", numerominimo);
	printf("printf d: numero negativo minimo.%d\n", numerominimo);
	ft_printf("ft_printf x: prueba numero maximo - 7fffffff %x\n", numeromaximo);
	printf("printf x: prueba numero maximo - 7fffffff %x\n", numeromaximo);
	ft_printf("ft_printf x: prueba numero minimo %x\n", numerominimo);
	printf("printf x: prueba numero minimo %x\n", numerominimo);
	ft_printf("ft_printf X: prueba numero -1 - %X\n", numero2);
	printf("printf X: prueba numero -1 - %X\n", numero2);
	ft_printf("ft_printf p: prueba puntero - %p\n", &numero);
	printf("printf p: prueba puntero - %p\n", &numero);
	ft_printf("ft_printf porcentaje: - %%\n");
	printf("printf porcentaje: - %%\n");
	return (0);
}