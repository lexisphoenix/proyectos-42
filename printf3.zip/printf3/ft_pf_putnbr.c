/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pf_putnbr.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anieto-m  <anieto-m@student.42.fr   >      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 20:05:00 by anieto-m          #+#    #+#             */
/*   Updated: 2025/08/12 16:08:26 by anieto-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_pf_putnbr(long int num)
{
	int	count;

	count = 0;
	if (num == 0)
	{
		count += ft_pf_putchar('0');
		return (count);
	}
	if (num < 0)
	{
		count += ft_pf_putchar('-');
		num = -num;
	}
	if (num >= 10)
	{
		count += ft_pf_putnbr(num / 10);
		count += ft_pf_putchar((num % 10) + '0');
	}
	else
		count += ft_pf_putchar(num + '0');
	return (count);
}
