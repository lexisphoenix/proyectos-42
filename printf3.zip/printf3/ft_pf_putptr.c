/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pf_putptr.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anieto-m  <anieto-m@student.42.fr   >      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 20:05:00 by anieto-m          #+#    #+#             */
/*   Updated: 2025/08/12 16:08:26 by anieto-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_pf_putptr(void *p)
{
	unsigned long long	star;
	int					count;

	star = (unsigned long long)p;
	if (!p)
	{
		ft_pf_putstr("(nil)");
		return (5);
	}
	count = 0;
	count += ft_pf_putstr("0x");
	count += ft_pf_puthexalow(star);
	return (count);
}
