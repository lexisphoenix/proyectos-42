/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pf_putunbr.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anieto-m  <anieto-m@student.42.fr   >      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 20:05:00 by anieto-m          #+#    #+#             */
/*   Updated: 2025/08/12 16:08:26 by anieto-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_pf_putunbr(unsigned int n)
{
	long int	num;
	long int	d;
	int			r;
	int			count;

	num = n;
	count = 0;
	if (num == 0)
	{
		count += ft_pf_putchar('0');
		return (count);
	}
	d = 1;
	while (num / d >= 10)
		d *= 10;
	while (d > 0)
	{
		r = num / d;
		count += ft_pf_putchar(r + '0');
		num %= d;
		d /= 10;
	}
	return (count);
}
