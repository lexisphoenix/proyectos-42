/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pf_puthexaup.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anieto-m  <anieto-m@student.42.fr   >      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 20:05:00 by anieto-m          #+#    #+#             */
/*   Updated: 2025/08/12 16:08:26 by anieto-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_pf_puthexaup(unsigned int p)
{
	int					count;
	char				*hexa;

	hexa = "0123456789ABCDEF";
	count = 0;
	if (p >= 16)
		count += ft_pf_puthexaup(p / 16);
	count += ft_pf_putchar(hexa[p % 16]);
	return (count);
}
